linuxmint@ece11 ~ $ gcc duplicatearray.c
linuxmint@ece11 ~ $ ./a.out
Enter the no. of Elements you want to insert 5
1 1 2 2 2
1 1 2 2 2  
1 Element is duplicate at arr[0] and arr[1]
  
2 Element is duplicate at arr[2] and arr[3]
  
2 Element is duplicate at arr[2] and arr[4]
  
2 Element is duplicate at arr[3] and arr[4]
 linuxmint@ece11 ~ $ 

